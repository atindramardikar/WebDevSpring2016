/**
 * Created by Sanjanamanoj on 2/29/2016.
 */
(function(){
    angular
        .module("EventSchedulerApp",["ngRoute", "gm.datepickerMultiSelect"]);
})();